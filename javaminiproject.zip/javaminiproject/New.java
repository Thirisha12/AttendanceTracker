import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.Map;
import java.util.HashMap;
import java.util.stream.Stream;
import java.util.*;
import java.io.*;
import java.util.Map.Entry;
import mypackage.*;


public class New {
  public static void main(String[] args) throws IOException {
    Scanner obj = new Scanner(System.in);
    String n;
      System.out.println("---------------------------------------------------------------------\n");
      System.out.println("\n                                 WELCOME TO    ");
      System.out.println("                       ATTENDANCE  MANAGEMENT  SYSTEM  ");
      System.out.println("\n\n-------------------------------------------------------------------");
      System.out.print("                    Student Login/ Teacher Login:  ");
      n = obj.next();
      if(n.equalsIgnoreCase("Student")){
      student stu=new student(n);
      stu.input();
      }
      else if(n.equalsIgnoreCase("Teacher")){
        teacher tea=new teacher(n);
        tea.input1();
      }
  }
}


