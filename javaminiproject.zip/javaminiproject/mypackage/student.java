package mypackage;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.Map;
import java.util.HashMap;
import java.util.stream.Stream;
import java.util.*;
import java.io.*;
import java.util.Map.Entry;

class myException extends Exception {
  myException() {
    System.out.println("\nInvalid Input");
  }
}

public class student{
  private String stu;
  public student(String stu){
    this.stu=stu;}
  
  Scanner obj = new Scanner(System.in);
  public void input(){
  int cont1 = 1;
  int number, i = 1, sub;
  String opt, opt1,clas, teach = "yes";
  while(cont1>0){
    String file=" ", n;
    String arr;
    System.out.print("                    Enter your class            :  ");
    arr=obj.next();
    if (arr.equalsIgnoreCase("cse"))
      file= "cse.txt";
    else if (arr.equalsIgnoreCase("ece"))
      file = "ece.txt";
    else if (arr.equalsIgnoreCase("eee"))
      file = "eee.txt";
    else if (arr.equalsIgnoreCase("it"))
      file = "it.txt";
    String delimiter = ":";
      Map<String, String> map = new HashMap<>();
      try (Stream<String> lines = Files.lines(Paths.get(file))) {
        lines.filter(line -> line.contains(delimiter)).forEach(
            line -> map.putIfAbsent(line.split(delimiter)[0], line.split(delimiter)[1]));
      }
    catch(IOException e){
      System.out.println("RETRY");
    }
      String key;
      System.out.print("                    Enter your official login ID:  ");
      key = obj.next();

      try {
        if (map.containsKey(key)) {
          System.out.println("\n\n                    Login Successful !!!");
          System.out.println("--------------------------------------------------------------");
          String value = map.get(key);
          String[] str = value.split(" ");
          System.out.println("                    WELCOME  " + str[0] + " :)");
          System.out.print("\n\nDo you want to view your details:  ");
          opt = obj.next();
          if (opt.equalsIgnoreCase("yes")) {
            System.out.println("\n");
            System.out.println("Your Details");
            System.out.println("-----------------");
            System.out.println("OOPS: " + str[1] + "%" + "\nDS  : " + str[2] + "%" + "\nDPSD: " + str[3] + "%"
                + "\nUHV : " + str[4] + "%");
            if (Integer.parseInt(str[1]) < 75) {
              System.out.println("\nYou have to attend more OOPS classes");
            }
            if (Integer.parseInt(str[2]) < 75) {
              System.out.println("\nYou have to attend more DS classes");
            }
            if (Integer.parseInt(str[3]) < 75) {
              System.out.println("\nYou have to attend more DPSD classes");
            }
            if (Integer.parseInt(str[4]) < 75) {
              System.out.println("\nYou have to attend more UHV classes");
            }
            System.out.println("------------------------------------------------------------\n");
            System.out.print("Do you want to view your attandance average  ?  ");
          opt1=obj.next();
          if(opt1.equalsIgnoreCase("yes")){
            int avg;
            avg=(Integer.parseInt(str[1])+Integer.parseInt(str[2])+Integer.parseInt(str[3])+Integer.parseInt(str[4]))/4;
            //System.out.println("-----------------------------");
            System.out.println("\nYour attendance average :"+" "+avg+" %");
          }
          } 
          else {
            System.out.println("Thanks for Visiting");
          }
        } else {
          throw new myException();
        }
      } catch (Exception e) {
        System.out.println("Wrong login ID Try again");
      }
    System.out.println("\n\n----------------------------------------------------------------");
    System.out.print("\nEnter 1 to continue,else 0 : ");
      cont1 = obj.nextInt();
    //}
    System.out.println("-----------------------------------------------------------------");
    System.out.println("\nThanks for visiting");
      
  } 
  }
}