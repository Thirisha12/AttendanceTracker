package mypackage;

import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.Map;
import java.util.HashMap;
import java.util.stream.Stream;
import java.util.*;
import java.io.*;
import java.util.Map.Entry;

class myException extends Exception {
  myException() {
    System.out.println("\nInvalid Input");
  }
}

public class teacher {
  private String teac;

  public teacher(String teac) {
    this.teac = teac;
  }

  Scanner obj = new Scanner(System.in);

  public void input1() {
    int cont1 = 1, flag;
    int number, i = 1, sub;
    float days;
    float percent;
    String opt, opt1, clas, teach = "yes", file = " ";
    while (cont1 > 0) {
      file = "teacher.txt";
      String delimiter = ":";
      Map<String, String> map = new HashMap<>();
      try (Stream<String> lines = Files.lines(Paths.get(file))) {
        lines.filter(line -> line.contains(delimiter)).forEach(
            line -> map.putIfAbsent(line.split(delimiter)[0], line.split(delimiter)[1]));
      } catch (IOException e) {
        System.out.println("RETRY");
      }
      String key;
      System.out.print("                    Enter your official login ID:  ");
      key = obj.next();

      try {
        if (map.containsKey(key)) {
          System.out.println("\n\n                    Login Successful !!!");
          System.out.println("--------------------------------------------------");
          String value = map.get(key);
          String[] str = value.split(" ");
          System.out.println("                    WELCOME " + str[0] + " :)");
        } else {
          throw new myException();
        }
      } catch (Exception e) {
        System.out.println("Wrong login ID Try again");
      }
      String fil = "";
      while (teach.equalsIgnoreCase("yes")) {
        // System.out.println("--------------------------------------------------");
        System.out.print("\nEnter the class to view :  ");
        clas = obj.next();
        if (clas.equalsIgnoreCase("cse"))
          fil = "cse.txt";
        else if (clas.equalsIgnoreCase("ece"))
          fil = "ece.txt";
        else if (clas.equalsIgnoreCase("eee"))
          fil = "eee.txt";
        else if (clas.equalsIgnoreCase("it"))
          fil = "it.txt";
        System.out.println("\nEnter the subject to view");
        System.out.println("1)OOPS\n2)DS\n3)DPSD\n4)UHV\n");
        sub = obj.nextInt();
        System.out.println("--------------------------------------------------");
        System.out.println("Purpose of visit ?\n");
        System.out.println(
            "1.VIEW STUDENT DETAILS\n2.EDIT THE STUDENT DETAILS\n3.VIEW STUDENTS WITHIN THE GIVEN LIMIT\n4.ATTENDANCE AVERAGE BETWEEN DATES");
        System.out.println("\n----------------------------------------------");
        System.out.print("Select the Purpose of visit :  ");
        int option = obj.nextInt();
       /////////////////////////////////////////////////
        if (option == 1) {
          System.out.println("\nSTUDENT DETAILS");
          System.out.println("----------------------------------------------");
          System.out.println("NO  NAME  ATT\n");
          try {
            FileReader fread = new FileReader(fil);
            String deli = ":";
            Map<String, String> map1 = new HashMap<>();
            try (Stream<String> lines = Files.lines(Paths.get(fil))) {
              lines.filter(line -> line.contains(deli))
                  .forEach(line -> map1.putIfAbsent(line.split(deli)[0], line.split(deli)[1]));
            } catch (IOException e5) {
              System.out.println("File not found");
            }
            Scanner sc = new Scanner(new File(fil));
            StringBuffer buffer = new StringBuffer();
            while (sc.hasNextLine()) {
              buffer.append(sc.nextLine() + System.lineSeparator());
            }
            String fileContents = buffer.toString();
            sc.close();

            for (Entry<String, String> entry : map1.entrySet()) {
              String value = entry.getValue();
              String[] str = value.split(" ");
              // System.out.println("NO NAME ATT");
              if (sub == 1)
                System.out.println(entry.getKey() + " " + str[0] + " " + str[1]);
              else if (sub == 2)
                System.out.println(entry.getKey() + " " + str[0] + " " + str[2]);
              else if (sub == 3)
                System.out.println(entry.getKey() + " " + str[0] + " " + str[3]);
              else if (sub == 4)
                System.out.println(entry.getKey() + " " + str[0] + " " + str[1]);
            }
          } catch (FileNotFoundException e1) {
            System.out.println("File not found");
          }
        }
        ////////////////////////////////////////////////////
        else if (option == 2) {
          String deli = ":";
          Map<String, String> map1 = new HashMap<>();
          try (Stream<String> lines = Files.lines(Paths.get(fil))) {
            lines.filter(line -> line.contains(deli))
                .forEach(line -> map1.putIfAbsent(line.split(deli)[0], line.split(deli)[1]));
          } catch (IOException e4) {
            System.out.println("file not found");
          }
          try {
            Scanner sc = new Scanner(new File(fil));
            StringBuffer buffer = new StringBuffer();
            while (sc.hasNextLine()) {
              buffer.append(sc.nextLine() + System.lineSeparator());
            }
            String fileContents = buffer.toString();
            sc.close();
            // float days;
            int percent1 = 0;
            // int sub;
            String num;

            if (sub == 1) {
              System.out.print("\nEnter the num of students to edit:  ");
              number = obj.nextInt();
              for (i = 0; i < number; i++) {
                System.out.print("Enter the student id to edit     :  ");
                num = obj.next();
                try {
                  if (map1.containsKey(num)) {
                    System.out.print("\nEnter the total num of working days  :  ");
                    float total = obj.nextFloat();
                    System.out.print("Enter the num of days student present:  ");
                    days = obj.nextFloat();
                    percent1 = (int) ((days / total) * 100);
                    String old = (num + ":" + map1.get(num));
                    String value = map1.get(num);
                    String[] str = value.split(" ");
                    String newline = (num + ":" + str[0] + " " + percent1 + " " + str[2] + " " + str[3] + " "
                        + str[4]);
                    fileContents = fileContents.replaceAll(old, newline);
                    FileWriter fwrite = new FileWriter(fil);
                    fwrite.append(fileContents);
                    fwrite.flush();
                    System.out.println("-------------------------------------------");
                    System.out.println("\nStudent Details edited Successfully\n");
                  } else {
                    throw new myException();
                  }
                } catch (Exception e) {
                  System.out.println("INVALID ID...Please Verify the ID");
                }
              }
            } else if (sub == 2) {
              System.out.print("\nEnter the num of students to edit:  ");
              number = obj.nextInt();
              for (i = 0; i < number; i++) {
                System.out.print("Enter the student id to edit:  ");
                num = obj.next();
                try {
                  if (map1.containsKey(num)) {
                    System.out.print("\nEnter the total num of working days:  ");
                    float total = obj.nextFloat();
                    System.out.print("Enter the num of days student present:  ");
                    days = obj.nextFloat();
                    percent1 = (int) ((days / total) * 100);
                    String old = (num + ":" + map1.get(num));
                    String value = map1.get(num);
                    String[] str = value.split(" ");
                    String newline = (num + ":" + str[0] + " " + str[1] + " " + percent1 + " " + str[3] + " "
                        + str[4]);
                    fileContents = fileContents.replaceAll(old, newline);
                    FileWriter fwrite = new FileWriter(fil);
                    fwrite.append(fileContents);
                    fwrite.flush();
                    System.out.println("\nStudent Detail edited Successfully\n");
                  } else {
                    throw new myException();
                  }
                } catch (Exception e) {
                  System.out.println("INVALID ID...Please Verify the ID");
                }
              }
            } else if (sub == 3) {
              System.out.print("\nEnter the num of students to edit:  ");
              number = obj.nextInt();
              for (i = 0; i < number; i++) {
                System.out.print("Enter the student id to edit:  ");
                num = obj.next();
                try {
                  if (map1.containsKey(num)) {
                    try {
                      System.out.print("\nEnter the total num of working days:  ");
                      float total = obj.nextFloat();
                      System.out.print("Enter the num of days student present:  ");
                      days = obj.nextFloat();
                      percent1 = (int) ((days / total) * 100);
                      String old = (num + ":" + map1.get(num));
                      String value = map1.get(num);
                      String[] str = value.split(" ");
                      String newline = (num + ":" + str[0] + " " + str[1] + " " + str[2] + " " + percent1 + " "
                          + str[4]);
                      fileContents = fileContents.replaceAll(old, newline);
                      FileWriter fwrite = new FileWriter(fil);
                      fwrite.append(fileContents);
                      fwrite.flush();
                      System.out.println("\nStudent Details edited Successfully\n");
                    } catch (FileNotFoundException ex) {
                      System.out.println("Retry");
                    }
                  } else {
                    throw new myException();
                  }
                } catch (Exception e) {
                  System.out.println("INVALID ID...Please Verify the ID");
                }
              }
            } else if (sub == 4) {
              System.out.print("\nEnter the num of students to edit:  ");
              number = obj.nextInt();
              for (i = 0; i < number; i++) {
                System.out.print("Enter the student id to edit:  ");
                num = obj.next();
                try {
                  if (map1.containsKey(num)) {
                    System.out.print("\nEnter the total num of working days:  ");
                    float total = obj.nextFloat();
                    System.out.print("Enter the num of days student present:  ");
                    days = obj.nextFloat();
                    percent1 = (int) ((days / total) * 100);
                    String old = (num + ":" + map1.get(num));
                    String value = map1.get(num);
                    String[] str = value.split(" ");
                    String newline = (num + ":" + str[0] + " " + str[1] + " " + str[2] + " " + str[3] + " "
                        + percent1);
                    fileContents = fileContents.replaceAll(old, newline);
                    FileWriter fwrite = new FileWriter(fil);
                    fwrite.append(fileContents);
                    fwrite.flush();
                    System.out.println("\nStudent Details edited Successfully\n");
                  } else {
                    throw new myException();
                  }
                } catch (Exception e) {
                  System.out.println("INVALID ID...Please Verify the ID");
                }
              }
            }
          } catch (FileNotFoundException ex) {
            System.out.println("Retry");
          }

        }

        ///////////////////////////////////////////////////////
        else if (option == 3) {
          System.out.println("----------------------------------------------");
          String deli = ":";
          flag = 0;
          Map<String, String> map1 = new HashMap<>();
          try (Stream<String> lines = Files.lines(Paths.get(fil))) {
            lines.filter(line -> line.contains(deli))
                .forEach(line -> map1.putIfAbsent(line.split(deli)[0], line.split(deli)[1]));
          } catch (IOException e7) {
            System.out.println("file not found");
          }
          int l1, l2;
          System.out.println("\nEnter the limit to check attendance :");
          l1 = obj.nextInt();
          l2 = obj.nextInt();
          System.out.println("----------------------------------------------");
          System.out.println("\nStudents below average Attendance");
          System.out.println("\nNO NAME  ATT");
          for (Entry<String, String> entry : map1.entrySet()) {
            String value = entry.getValue();
            String[] str = value.split(" ");
            if (sub == 1) {
              if (Integer.parseInt(str[1]) > l1 && Integer.parseInt(str[1]) < l2) {
                System.out.println(entry.getKey() + " " + str[0] + " " + str[1]);
                flag = 1;
              }
            } else if (sub == 2) {
              if (Integer.parseInt(str[2]) > l1 && Integer.parseInt(str[2]) < l2) {
                System.out.println(entry.getKey() + " " + str[0] + " " + str[2]);
                flag = 1;
              }
            } else if (sub == 3) {
              if (Integer.parseInt(str[3]) > l1 && Integer.parseInt(str[3]) < l2) {
                System.out.println(entry.getKey() + " " + str[0] + " " + str[3]);
                flag = 1;
              }
            } else if (sub == 4) {
              if (Integer.parseInt(str[4]) > l1 && Integer.parseInt(str[4]) < l2) {
                System.out.println(entry.getKey() + " " + str[0] + " " + str[4]);
                flag = 1;
              }
            }

            else {
              System.out.println("\nError in selection option");
            }
          }
          if (flag == 0) {
            System.out.println("\n***  NO student in the given range ***\n");
          }

        } 
        else if (option == 4) {
          float absent = 0.0f;
          float present = 0.0f;
          int days1,d1,d2;
          String num;
          if (sub == 1) {
            String deli = ":";
            Map<String, String> map1 = new HashMap<>();
            try (Stream<String> lines = Files.lines(Paths.get("oopsatt.txt"))) {
              lines.filter(line -> line.contains(deli))
                  .forEach(line -> map1.putIfAbsent(line.split(deli)[0], line.split(deli)[1]));
            } catch (IOException e4) {
              System.out.println("file not found");
            }
            System.out.print("\nEnter the student ID to calculate :  ");
            key = obj.next();
            try {
              String value = map1.get(key);
              String[] str = value.split("  ");

              System.out.println("Enter the dates : ");
              d1 = obj.nextInt();
              d2 = obj.nextInt();
              for (i = d1 - 1; i < d2; i++) {
                //System.out.print(str[i] + ",");
                try {
                  if (Integer.parseInt(str[i]) == 1)
                    present++;
                  else
                    absent++;
                } catch (NumberFormatException e9) {
                  System.out.println("number format");
                }
              }
              System.out.println("-----------------------------------------------");
              System.out.println("\nPRESENT DAYS:  " + present);
              System.out.println("ABSENT DAYS :  " + absent);
              // System.out.println("Enter the total number of working days:");
              days1 = (d2 - d1) + 1;
              //System.out.println("DAYS" + days1);
              percent = (present / days1) * 100;
              System.out.println("\nAverage Percentage:  " + (int) percent+" %");
            } catch (NullPointerException e8) {
              System.out.println("Invalid ID ");
            }
          }
          else if (sub == 2) {
            String deli = ":";
            Map<String, String> map1 = new HashMap<>();
            try (Stream<String> lines = Files.lines(Paths.get("dsatt.txt"))) {
              lines.filter(line -> line.contains(deli))
                  .forEach(line -> map1.putIfAbsent(line.split(deli)[0], line.split(deli)[1]));
            } catch (IOException e4) {
              System.out.println("file not found");
            }
            System.out.print("\nEnter the student ID to calculate :  ");
            key = obj.next();
            try {
              String value = map1.get(key);
              String[] str = value.split("  ");

              System.out.println("Enter the dates : ");
              d1 = obj.nextInt();
              d2 = obj.nextInt();
              for (i = d1 - 1; i < d2; i++) {
                //System.out.print(str[i] + ",");
                try {
                  if (Integer.parseInt(str[i]) == 1)
                    present++;
                  else
                    absent++;
                } catch (NumberFormatException e9) {
                  System.out.println("number format");
                }
              }
              System.out.println("-----------------------------------------------");
              System.out.println("\nPRESENT DAYS:  " + present);
              System.out.println("ABSENT DAYS :  " + absent);
              // System.out.println("Enter the total number of working days:");
              days1 = (d2 - d1) + 1;
              //System.out.println("DAYS" + days1);
              percent = (present / days1) * 100;
              System.out.println("\nAverage Percentage:  " + (int) percent+" %");
            } catch (NullPointerException e8) {
              System.out.println("Invalid ID ");
            }
          }
          else if (sub == 3) {
            String deli = ":";
            Map<String, String> map1 = new HashMap<>();
            try (Stream<String> lines = Files.lines(Paths.get("dpsdatt.txt"))) {
              lines.filter(line -> line.contains(deli))
                  .forEach(line -> map1.putIfAbsent(line.split(deli)[0], line.split(deli)[1]));
            } catch (IOException e4) {
              System.out.println("file not found");
            }
            System.out.print("\nEnter the student ID to calculate :  ");
            key = obj.next();
            try {
              String value = map1.get(key);
              String[] str = value.split("  ");

              System.out.println("Enter the dates : ");
              d1 = obj.nextInt();
              d2 = obj.nextInt();
              for (i = d1 - 1; i < d2; i++) {
                //System.out.print(str[i] + ",");
                try {
                  if (Integer.parseInt(str[i]) == 1)
                    present++;
                  else
                    absent++;
                } catch (NumberFormatException e9) {
                  System.out.println("number format");
                }
              }
              System.out.println("-----------------------------------------------");
              System.out.println("\nPRESENT DAYS:  " + present);
              System.out.println("ABSENT DAYS :  " + absent);
              // System.out.println("Enter the total number of working days:");
              days1 = (d2 - d1) + 1;
              //System.out.println("DAYS" + days1);
              percent = (present / days1) * 100;
              System.out.println("\nAverage Percentage:  " + (int) percent+" %");
            } catch (NullPointerException e8) {
              System.out.println("Invalid ID ");
            }
          }
          else if (sub == 4) {
            String deli = ":";
            Map<String, String> map1 = new HashMap<>();
            try (Stream<String> lines = Files.lines(Paths.get("uhvatt.txt"))) {
              lines.filter(line -> line.contains(deli))
                  .forEach(line -> map1.putIfAbsent(line.split(deli)[0], line.split(deli)[1]));
            } catch (IOException e4) {
              System.out.println("file not found");
            }
            System.out.print("\nEnter the student ID to calculate :  ");
            key = obj.next();
            try {
              String value = map1.get(key);
              String[] str = value.split("  ");

              System.out.println("Enter the dates : ");
              d1 = obj.nextInt();
              d2 = obj.nextInt();
              for (i = d1 - 1; i < d2; i++) {
                //System.out.print(str[i] + ",");
                try {
                  if (Integer.parseInt(str[i]) == 1)
                    present++;
                  else
                    absent++;
                } catch (NumberFormatException e9) {
                  System.out.println("number format");
                }
              }
              System.out.println("-----------------------------------------------");
              System.out.println("\nPRESENT DAYS:  " + present);
              System.out.println("ABSENT DAYS :  " + absent);
              // System.out.println("Enter the total number of working days:");
              days1 = (d2 - d1) + 1;
              //System.out.println("DAYS" + days1);
              percent = (present / days1) * 100;
              System.out.println("\nAverage Percentage:  " + (int) percent+" %");
            } catch (NullPointerException e8) {
              System.out.println("Invalid ID ");
            }
          }
        }
        System.out.println("-------------------------------------------------");
        System.out.print("\nDo you want to continue the work:  ");
        teach = obj.next();

      }

      System.out.println("\nEnter 1 to continue,else 0");
      cont1 = obj.nextInt();
      // }
      System.out.println("---------------------------------------------------");
      System.out.println("\nThanks for visiting");
    }
  }

}